export const getContactList = () => {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(Array.from({ length: 10 }, (item, i) => ({ id: i })))
        }, 2000)
    })
}