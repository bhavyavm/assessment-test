export const setUserSession = (data) => {
    localStorage.setItem('user-token', data);
}
export const unsetUserSession = (data) => {
    localStorage.removeItem('user-token', data);
}
export const getUserSession = (data) => {
    localStorage.getItem('user-token');
}
