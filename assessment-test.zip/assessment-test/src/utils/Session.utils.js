export const setItem = (key, data) => {
    return localStorage.setItem(key, data);
}
export const unsetItem = (key) => {
    return localStorage.removeItem(key);
}
export const getItem= (key) => {
    return localStorage.getItem(key);
}

