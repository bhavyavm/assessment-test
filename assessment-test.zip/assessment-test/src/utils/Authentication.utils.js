import { getItem } from "./Session.utils";
import { Navigate } from 'react-router-dom';
import Header from "../Components/Header/Header";

const isAuthenticated = (Component)=>{
    if (!getItem('user-token')) {
        return <Navigate to="/" />;
      } else {
        return (<div>
            <Header />
            {Component}
        </div>);
      }
}

  export default isAuthenticated;