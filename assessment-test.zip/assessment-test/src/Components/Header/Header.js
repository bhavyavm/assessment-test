import './Header.css';
import { unsetItem } from '../../utils/Session.utils';
import { useNavigate } from 'react-router-dom';

const Header = (props) => {
    let navigate = useNavigate();
    const onLogout = () =>{
        unsetItem('user-token');
        navigate('/');
    }
    
    return (
        <div className='wrapper'>
            <h2>Infinite Scroll App</h2>
            <button onClick={onLogout}> LogOut</button>
       </div>
    )
}
export default Header