import './InfiniteList.css'
const InfiniteList = (props) => {
    return (
        <>
            {props.contactList.map((contact) => (<div className="contact-item">
                    <div  className='contact-img' >Img</div>
                 <div className='contact-text'>name</div>
                 </div>))}
        </>
    )
}
export default InfiniteList