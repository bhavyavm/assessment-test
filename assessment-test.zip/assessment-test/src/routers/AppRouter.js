import React from 'react';
import { BrowserRouter, Route, Routes } from "react-router-dom";
import PagenotFound from '../pages/PageNotFound';
import Home from '../pages/Home/Home';
import Login from '../pages/Login/Login';
import isAuthenticated from '../utils/Authentication.utils';

const AppRouter = () => {
    return (
        <BrowserRouter >
                <Routes>
                    <Route exact path="/" element={<Login/>} />
                    <Route exact path="/home" element={isAuthenticated(<Home />)} />
                    <Route element={PagenotFound} />
                </Routes>
        </BrowserRouter>
    );
}
export default AppRouter;