import React, { useEffect, useRef, useState } from "react";
import InfiniteList from "../../Components/InfiniteList/InfiniteList";
import { getContactList } from './../../APIS/api';
import Loader from '../../Components/Loader/Loader';
import './Home.css'

const Home = () => {
    const wrapperRef = useRef(null)
    const [contactList, updateContactList] = useState([
        { id: 1 },
        { id: 2 },
        { id: 3 },
        { id: 4 },
        { id: 5 },
        { id: 6 },
        { id: 7 },
        { id: 8 },
        { id: 9 },
        { id: 10 },
    ]);

    const CB = async entries=> {
        const [entry] = entries;
        if (entry.isIntersecting) {
           const response = await getContactList();
           updateContactList([...contactList, ...response])
        }
    }

    const options = {
        root: null,
        rootMargin: '0px 0px 100% 0px',
        threshold: 0
    }

    useEffect(() => {
        const observer = new IntersectionObserver(CB, options);
        if (wrapperRef.current) observer.observe(wrapperRef.current);

        return () => {
            if (wrapperRef.current) observer.unobserve(wrapperRef.current);
        }
    }, [wrapperRef, options])

    return (
        <div>
            <div>
                <InfiniteList contactList={contactList} />
            </div>
            <div className='scroller-loader' ref={wrapperRef}><Loader /></div>
        </div>
    );
}

export default Home;


