
import React, { useEffect, useState } from 'react';
import { setItem, getItem } from '../../utils/Session.utils';
import './login.css';

export default function Login() {

    useEffect(()=>{
        if(getItem('user-token')){
            window.location.href='/home';
        }

    },[])

    const [userName, updateUserName] = useState('') 
    const [password, updatePassword] = useState('') 

    const handleFormSubmit = (e) => {
        if (userName==='foo' && password==='bar') {
            setItem('user-token', "123456789");
            window.location.href='/home';
        }else{
            alert('Invalid credentials')
        }
    }

    return (
        <div className="login-wrapper">
            <div>
            <h1>Please Log In</h1>
            <label>
                    <p>Username</p>
                    <input type="text" name="username" onChange={(e)=>updateUserName(e.target.value)}/>
                </label>
                <label>
                    <p>Password</p>
                    <input type="password" name="password" onChange={(e)=>updatePassword(e.target.value)}/>
                </label>
                <div>
                    <button onClick={handleFormSubmit} >Submit</button>
                </div>
        </div>
        </div>
    )
}